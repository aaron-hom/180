CREATE INDEX LookUpFlightTickets 
       ON Tickets (AirlineID, FlightNum);
 
